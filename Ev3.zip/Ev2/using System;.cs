using System;

class Program
{
    static void Main(string[] args)
    {
        // Solicitar la dimensión del arreglo al usuario
        Console.Write("¿Cuál es la cantidad de renglones del arreglo? ");
        int rows = int.Parse(Console.ReadLine());
        Console.Write("¿Cuál es la cantidad de columnas del arreglo? ");
        int cols = int.Parse(Console.ReadLine());

        // Crear el arreglo bidimensional y llenarlo con valores aleatorios entre 0 y 9
        int[,] array = new int[rows, cols];
        Random rand = new Random();
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                array[i, j] = rand.Next(10);
            }
        }

        // Calcular la cantidad de ceros en el arreglo y desplegarla
        int totalZeros = 0;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (array[i, j] == 0)
                {
                    totalZeros++;
                }
            }
        }
        Console.WriteLine("Cantidad de ceros: " + totalZeros);

        // Calcular la cantidad de ceros por renglón y desplegarla
        Console.Write("Cantidad de ceros por renglón: ");
        for (int i = 0; i < rows; i++)
        {
            int zerosInRow = 0;
            for (int j = 0; j < cols; j++)
            {
                if (array[i, j] == 0)
                {
                    zerosInRow++;
                }
            }
            Console.Write(zerosInRow + " ");
        }
        Console.WriteLine();

        // Calcular la cantidad de ceros por columna y desplegarla
        Console.Write("Cantidad de ceros por columna: ");
        for (int j = 0; j < cols; j++)
        {
            int zerosInCol = 0;
            for (int i = 0; i < rows; i++)
            {
                if (array[i, j] == 0)
                {
                    zerosInCol++;
                }
            }
            Console.Write(zerosInCol + " ");
        }
        Console.WriteLine();
    }
}
